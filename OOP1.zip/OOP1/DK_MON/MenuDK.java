package OOP1.DK_MON;


import java.util.Scanner;

public class MenuDK {

    public static void main(String[] args) {
            Scanner nhap = new Scanner(System.in);
            int luaChon;
            QuanMDK qld = new QuanMDK();

            do {
                System.out.println("_____________MENU ĐĂNG KÍ___________");
                System.out.println("1. Thêm danh sách môn đăng kí ");
                System.out.println("2. Xóa danh sách môn đăng kí ");
                System.out.println("3. Đọc File ");
                System.out.println("4. Ghi File ");
                System.out.println("5. In danh sách môn học ");
                System.out.println("6. In danh sáng đăng kí của sinh viên ");
                System.out.println("7. Chọn môn học ");
                System.out.println("0. Chọn 0 để thoát");
                luaChon=nhap.nextInt();
                nhap.nextLine();

                switch (luaChon) {
                    case 1: {
                        System.out.print("Nhập mã môn học: ");
                        String maMonHoc = nhap.nextLine();
                        System.out.print("Nhập tên môn học : ");
                        String tenMonHoc = nhap.nextLine();                  System.out.print("Nhập tên môn học : ");
                        System.out.print("Nhập nhóm: ");
                        String nhom = nhap.nextLine();
                        System.out.print("Nhập số tín chỉ: ");
                        String tinchi = nhap.nextLine();
                        System.out.print("Nhập số tiết: ");
                        String sotiet = nhap.nextLine();
                        System.out.print("Nhập học phí: ");
                        String hocphi = nhap.nextLine();
                        Mon m = new Mon(maMonHoc,tenMonHoc,nhom,tinchi,sotiet,hocphi);
                        qld.themDSMon(m);
                        break;
                    }
                    case 2: {
                        System.out.println("Nhập vào tên môn học: ");
                        String tenmh=nhap.nextLine();
                        Mon tenmon = new Mon(tenmh);
                        System.out.println(qld.xoaDSMon(tenmon));
                        break;
                    }
                    case 3: {
                        qld.docFileDSMH();
                        break;
                    }
                    case 4: {
                        qld.ghiFileD();
                        break;
                    }
                    case 5: {
                        qld.inDSDK();
                        break;
                    }
                    case 6: {
                        qld.inDSSVChon();
                        break;
                    }
                    case 7: {
                        System.out.println("Nhập vào tên môn học: ");
                        String tenmh=nhap.nextLine();
                        Mon tenmon = new Mon(tenmh);
                        qld.chonMonDK(tenmon);
                        break;
                    }
                    default:
                        break;
                }
            }
            while(luaChon!=0);
    }
}

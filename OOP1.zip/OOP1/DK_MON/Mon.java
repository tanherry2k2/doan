package OOP1.DK_MON;


public class Mon {
	private String maMonHoc;
	private String tenMonHoc;
	private String nhom;
	private String soTinChi;
	private String soTiet;
	public String hocPhi;

	public Mon(String maMonHoc, String tenMonHoc, String nhom, String soTinChi, String soTiet, String hocPhi) {
		this.maMonHoc = maMonHoc;
		this.tenMonHoc = tenMonHoc;
		this.nhom = nhom;
		this.soTinChi = soTinChi;
		this.soTiet = soTiet;
		this.hocPhi = hocPhi;
	}

	public Mon(String tenmh) {
	}

	public String getMaMonHoc() {
		return maMonHoc;
	}

	public void setMaMonHoc(String maMonHoc) {
		this.maMonHoc = maMonHoc;
	}

	public String getTenMonHoc() {
		return tenMonHoc;
	}

	public void setTenMonHoc(String tenMonHoc) {
		this.tenMonHoc = tenMonHoc;
	}

	public String getNhom() {
		return nhom;
	}

	public void setNhom(String nhom) {
		this.nhom = nhom;
	}

	public String getSoTinChi() {
		return soTinChi;
	}

	public void setSoTinChi(String soTinChi) {
		this.soTinChi = soTinChi;
	}

	public String getSoTiet() {
		return soTiet;
	}

	public void setSoTiet(String soTiet) {
		this.soTiet = soTiet;
	}

	public String getHocPhi() {
		return hocPhi;
	}

	public void setHocPhi(String hocPhi) {
		this.hocPhi = hocPhi;
	}

	@Override
	public String toString() {
		return "Mon{" +
				"maMonHoc='" + maMonHoc + '\'' +
				", tenMonHoc='" + tenMonHoc + '\'' +
				", nhom='" + nhom + '\'' +
				", soTinChi='" + soTinChi + '\'' +
				", soTiet='" + soTiet + '\'' +
				", hocPhi='" + hocPhi + '\'' +
				'}';
	}
}
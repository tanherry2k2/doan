package OOP1.DK_MON;


import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;


public class QuanMDK {

    private ArrayList<Mon> mon=new ArrayList<Mon>();
    Mon m;
    Scanner nhap = new Scanner(System.in);
    QuanMDK(ArrayList<Mon> m) {
        this.mon = m;
    }

	public QuanMDK() {
	}

	public void themDSMon(Mon m) {
        this.mon.add(m);
    }

    public boolean xoaDSMon(Mon tenmon) {
              return  this.mon.remove(tenmon);
    }
    public void inDSDK() {
    	for (Mon mon1 : mon) {
			System.out.println(mon1);
        }
    }
    public void inDSSVChon() {
        docFileDSMHSV();
        for (Mon mon1 : mon) {
            System.out.println(mon1);
        }
    }
    public Mon docFileDSMH() {
        try {
            FileReader fr = new FileReader("src/OOP/TEST/docfileDSDK");
            BufferedReader bf = new BufferedReader(fr);
            String line="";
            String[] temp;
            while ((line = bf.readLine()) != null) {
                temp = line.split(",");
                Mon m = taoDSMon(temp);
                this.mon.add(m);
            }
            System.out.println("Đã đọc file");
            bf.close();
            fr.close();
        } catch (IOException e) {
            System.out.println("Không tìm thấy file");
        }
        return null;
    }
    public void docFileDSMH(Mon tenMH) {
        try {
            FileReader fr = new FileReader("src/OOP/TEST/docfileDSDK");
            BufferedReader bf = new BufferedReader(fr);
            String line="";
            String[] temp;
            if (equals(tenMH)){
                temp = line.split(",");
                Mon m = taoDSMon(temp);
                this.mon.add(m);
            }
            System.out.println("Đã đọc file");
            bf.close();
            fr.close();
        } catch (IOException e) {
            System.out.println("Không tìm thấy file");
        }
    }
    public void docFileDSMHSV() {
        try {
            FileReader fr = new FileReader("src/OOP/TEST/DSDK_SV_DK");
            BufferedReader bf = new BufferedReader(fr);
            String line="";
            String[] temp;
            while ((line = bf.readLine()) != null) {
                temp = line.split(",");
                Mon m = taoDSMon(temp);
                this.mon.add(m);
            }
            System.out.println("Đã đọc file");
            bf.close();
            fr.close();
        } catch (IOException e) {
            System.out.println("Không tìm thấy file");
        }
    }
    private Mon taoDSMon(String[] temp) {
        String maMh = temp[0];
        String tenMh = temp[1];
        String nhom = temp[2];
        String sotinChi = temp[3];
        String soTiet = temp[4];
        String hocPhi = temp[5];
        Mon m = new Mon(maMh,tenMh,nhom,sotinChi,soTiet,hocPhi);
        return m;
    }
//    public String ReadFile(String tenMH) {
//        try{
//            String[] content = System.IO.File.ReadAllLine("src/OOP/TEST/DSDK_SV_DK");
//            return content[i];
//        }
//        catch{
//            return "Không ghi được file";)
//        }
//    }

    public void ghiFileD() {
        try {
            FileWriter fw = new FileWriter("src/OOP/TEST/DSMH_SV_DK");
            BufferedWriter bw = new BufferedWriter(fw);
            for (Mon m: mon) {
                if (m instanceof Mon) {
                    bw.write(m.getMaMonHoc()+","+
                            m.getTenMonHoc()+","+
                            m.getNhom()+","+
                            m.getSoTinChi()+","+
                            m.getSoTiet()+","+
                            m.getHocPhi()
                    )  ;

                    bw.newLine();
                }
            }
            System.out.println("Đã ghi file");
            bw.close();
            fw.close();
        } catch (IOException e) {
            System.out.println("Không ghi được file ");
        }
    }
    public void ghiFileD(Mon TenMH) {
        try {
            FileWriter fw = new FileWriter("src/OOP/TEST/DSMH_SV_DK");
            BufferedWriter bw = new BufferedWriter(fw);
            for (Mon m: mon) {
                if (m instanceof Mon) {
                    bw.write(m.getMaMonHoc()+","+
                                    m.getTenMonHoc()+","+
                                    m.getNhom()+","+
                                    m.getSoTinChi()+","+
                                    m.getSoTiet()+","+
                            m.getHocPhi()
                            )  ;

                    bw.newLine();
                }
            }
            System.out.println("Đã ghi file");
            bw.close();
            fw.close();
        } catch (IOException e) {
            System.out.println("Không ghi được file ");
        }
    }
    public void timMonDK(String TenMH) {
        for (Mon m : mon) {
            if(m.getTenMonHoc().equals(TenMH))
                System.out.println(m);
        }
    }
    public void chonMonDK(Mon TenMH) {
        docFileDSMH(TenMH);
        for (Mon m : mon) {
            if (m.getTenMonHoc().equals(TenMH)) {
                System.out.println("Bạn đã đăng kí môn học này. Vui lòng chọn môn chưa đăng kí!");
            } else {
                System.out.println("Bạn có muôn lưu môn đăng kí ");
                System.out.println("1: Có ");
                System.out.println("2: Không ");
                int chon = nhap.nextInt();
                nhap.nextLine();
                switch (chon) {
                    case 1: {
                        ghiFileD(TenMH);
                        break;
                    }
                    default:
                        break;
                }
            }
        }
    }

}


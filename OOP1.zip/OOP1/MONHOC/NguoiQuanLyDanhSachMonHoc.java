package OOP1.MONHOC;

public interface  NguoiQuanLyDanhSachMonHoc{
	public   void themMonHoc(MonHoc mh) ;
	public boolean xoaMonHoc(MonHoc maMonHoc);
	public void capNhapMonHoc(MonHoc hhh);
	public void docFileMH();
	public void ghiFileMH();
	public void xemDanhSachMonHoc();
	public void xemmontheoNganh();
	public void timMonHocTheoTen(String tenMonHoc2);
}

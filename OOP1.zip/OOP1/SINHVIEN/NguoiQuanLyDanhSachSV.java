package OOP1.SINHVIEN;

public interface NguoiQuanLyDanhSachSV {
    void themSinhVien(SinhVien sinhVien);

    void suaThongTin(SinhVien sv);

    void inDanhSachSinhVien();

    void docFileSV();

    void ghiFileSV();

    boolean kiemTraDanhSachCRongHayKhong();

    int laySoLuongSinhVien();

    void lamRongDanhSach();

    boolean kiemTraTonTai(SinhVien sv);

    boolean xoaSinhVien(SinhVien sv);

    void timSinhVien(String ten);

    void sapXepDanhSachTheoNamSinhTangDan();
}
